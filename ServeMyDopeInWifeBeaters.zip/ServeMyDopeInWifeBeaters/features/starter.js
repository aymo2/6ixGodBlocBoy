// Variable to keep track of the functionality state
let isEnabled = true;

// Register a chat trigger
register("chat", (message, event) => {
    if (!isEnabled) return;

    // Check if the message contains "ping" (case-insensitive)
    if (message.toLowerCase().includes("trespass")) {
        // Send a chat message saying "Pong!"
        ChatLib.say("/pc !start");
    }
}).setChatCriteria("${message}");

// Register the toggle command
register("command", () => {
    isEnabled = !isEnabled;
    ChatLib.chat("§bMo client is now §d" + (isEnabled ? "enabled" : "disabled"));
}).setName("aymo");