// Command to switch to the first hotbar slot
register("command", () => {
    const index = 0;  // First hotbar slot

    const initialIndex = Player.getHeldItemIndex();
    const shouldSwap = initialIndex !== index;

    if (shouldSwap) {
        Player.setHeldItemIndex(index);
    }

    ChatLib.chat("§f6ixGod's pick!");
}).setName("switchfirst");

// Command to switch to the fourth hotbar slot
register("command", () => {
    const index = 3;  // Fourth hotbar slot (index starts from 0)

    const initialIndex = Player.getHeldItemIndex();
    const shouldSwap = initialIndex !== index;

    if (shouldSwap) {
        Player.setHeldItemIndex(index);
    }

    ChatLib.chat("§f6ixGod's tnt!");
}).setName("switchfourth");

// Command to switch to the fifth hotbar slot
register("command", () => {
    const index = 4;  // Fourth hotbar slot (index starts from 0)

    const initialIndex = Player.getHeldItemIndex();
    const shouldSwap = initialIndex !== index;

    if (shouldSwap) {
        Player.setHeldItemIndex(index);
    }

    ChatLib.chat("§f6ixGod: HERE HAPPY WITH UR BONZO?!?!?");
}).setName("switchfifth");
