// Define a function that replicates the original functionality
function performAction() {
    ChatLib.say(".toggle hclip");
    setTimeout(() => {
        ChatLib.say(".toggle hclip");
    }, 70);
}

// Register the /pressf1 command to execute the action
register("command", () => {
    performAction();
}).setName("pressf1"); // Command is '/pressf1'