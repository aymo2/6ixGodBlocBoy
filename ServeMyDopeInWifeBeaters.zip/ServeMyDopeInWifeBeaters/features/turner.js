// Register a listener for action bar or other client-side messages
register("actionBar", (message) => {
    if (message.toLowerCase().includes("pearlclip activated")) {
        ChatLib.chat("&aDetected PearlClip activation from the action bar. Preparing to throw the pearl.");
        handlePearlClip();
    }
});
