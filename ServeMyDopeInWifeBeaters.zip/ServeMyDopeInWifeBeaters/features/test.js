// Constants
const PREFIX = "&f[&cButtonDetector&f]";
let enabled = true;
let debugMode = false;  // Set to true temporarily if we need to check exact pitch values

// Register sound event
register("soundPlay", (position, name, volume, pitch, categoryName, event) => {
    if (!enabled) return;

    // Show all sounds when debug mode is enabled
    if (debugMode) {
        ChatLib.chat(PREFIX + " &7Sound: " + name + " | Pitch: " + pitch);
    }
    
    // Continue only if the sound is "random.click" and it's not the ignored pitch range
    if (name === "random.click") {
        
        // Ignore sounds with pitch below 0.5
        if (pitch < 0.5) return;
        
        // Button press is typically a lower pitch than the release
        if (pitch < 1.0) {  // Adjust this value if needed
            ChatLib.chat("&f&lBUTTON PRESS DETECTED!");
        }
    }
});

// Toggle command
register("command", () => {
    enabled = !enabled;
    ChatLib.chat(PREFIX + (enabled ? " &aEnabled" : " &cDisabled"));
}).setName("buttondetector");

// Debug command to see pitch values of all sounds
register("command", () => {
    debugMode = !debugMode;
    ChatLib.chat(PREFIX + (debugMode ? " &aDebug Mode ON - showing all sound types and pitch values" : " &cDebug Mode OFF"));
}).setName("buttondebug");

// Startup message
ChatLib.chat(PREFIX + " &aLoaded! Use /buttondetector to toggle");
