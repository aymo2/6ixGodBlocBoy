// Constants
const PREFIX = "&f[&ftesterwester&f]";

register("command", () => {
    Thread.sleep(50); // Wait for 50ms
    rightClick(); // Call the function to simulate right-click
}).setName("click");

// Function to perform a right-click using the Robot class
function rightClick() {
    ChatLib.chat(PREFIX + " &ftrynna right click");

    // Execute the click in a new thread to prevent game freezes
    new Thread(() => {
        try {
            const Robot = Java.type("java.awt.Robot");
            const InputEvent = Java.type("java.awt.event.InputEvent");
            const robot = new Robot();

            robot.mousePress(InputEvent.BUTTON3_DOWN_MASK);
            robot.delay(5); // Reduced delay to minimize freezing
            robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);
            ChatLib.chat(PREFIX + " &fit worked");
        } catch (e) {
            ChatLib.chat(PREFIX + " &cError with Robot method: " + e);
        }
    }).start();
}