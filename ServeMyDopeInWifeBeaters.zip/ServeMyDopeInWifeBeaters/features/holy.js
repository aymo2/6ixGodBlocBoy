// Debugging listener to capture and log all chat messages for troubleshooting
register("chat", (message) => {
    const msg = message.getUnformattedText();
    ChatLib.chat(`&bReceived message: ${msg}`);  // Log each incoming message to verify format

    // Check if the message matches the expected block format
    const match = msg.match(/Block at \((-?\d+), (-?\d+), (-?\d+)\): Block\{type=minecraft:prismarine/);
    if (match) {
        const x = match[1];
        const y = match[2];
        const z = match[3];

        ChatLib.chat(`&aDetected block coordinates: X=${x}, Y=${y}, Z=${z}`);  // Confirm coordinates are captured
        ChatLib.command(`rotata ${x} ${y} ${z}`);  // Execute the /rotata command with extracted coordinates
    }
});
