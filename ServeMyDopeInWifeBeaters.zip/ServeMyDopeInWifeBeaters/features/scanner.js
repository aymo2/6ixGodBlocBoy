import { lookAtCoordinates } from "./stare";

class SimpleScanner {
    scan(distance) {
        const playerX = Math.floor(Player.getX());
        const playerY = Math.floor(Player.getY());
        const playerZ = Math.floor(Player.getZ());

        // Check +X position
        let block = World.getBlockAt(playerX + distance, playerY, playerZ);
        ChatLib.chat(`&7Block at (${playerX + distance}, ${playerY}, ${playerZ}): ${block}`);
        if (block.toString().includes('prismarine')) {
            let x = parseFloat(playerX + distance);
            let y = parseFloat(playerY);
            let z = parseFloat(playerZ);

            lookAtCoordinates(x,y,z);
        }

        // Check -X position
        block = World.getBlockAt(playerX - distance, playerY, playerZ);
        ChatLib.chat(`&7Block at (v${playerX - distance}, ${playerY}, ${playerZ}): ${block}`);
        if (block.toString().includes('prismarine')) {
            let x = parseFloat(playerX - distance);
            let y = parseFloat(playerY);
            let z = parseFloat(playerZ);

            lookAtCoordinates(x,y,z);
        }
        // Check +Z position
        block = World.getBlockAt(playerX, playerY, playerZ + distance);
        ChatLib.chat(`&7Block at (${playerX}, ${playerY}, ${playerZ + distance}): ${block}`);
        if (block.toString().includes('prismarine')) {
            let x = parseFloat(playerX);
            let y = parseFloat(playerY);
            let z = parseFloat(playerZ + distance);

            lookAtCoordinates(x,y,z);
        }

        // Check -Z position
        block = World.getBlockAt(playerX, playerY, playerZ - distance);
        ChatLib.chat(`&7Block at (${playerX}, ${playerY}, ${playerZ - distance}): ${block}`);
        if (block.toString().includes('prismarine')) {
            let x = parseFloat(playerX);
            let y = parseFloat(playerY);
            let z = parseFloat(playerZ - distance);

            lookAtCoordinates(x,y,z);
        }
    }
}

// Register the command with a distance parameter
register("command", (distance) => {
    if (!distance) {
        ChatLib.chat("&cPlease specify a distance! Usage: /scan <distance>");
        return;
    }

    const scanner = new SimpleScanner();
    scanner.scan(parseInt(distance));
}).setName("scan");