let checkInterval = 20; // Check every 20 ticks (roughly 1 second)
let tickCounter = 0;

register("step", () => {
    tickCounter++;
    if (tickCounter >= checkInterval) {
        tickCounter = 0; // Reset the counter after reaching the interval
        checkEnderPearlCount();
    }
});

function checkEnderPearlCount() {
    // Loop through the hotbar slots (0-8)
    for (let i = 0; i < 9; i++) {
        let item = Player.getInventory().getStackInSlot(i);

        // Check if the item is an Ender Pearl and if the count is less than 3
        if (item && item.getName().includes("Ender Pearl") && item.getStackSize() < 3) {
            ChatLib.command("/ep", true); // Runs the /ep command silently
            break; // Exit the loop once the command is run
        }
    }
}