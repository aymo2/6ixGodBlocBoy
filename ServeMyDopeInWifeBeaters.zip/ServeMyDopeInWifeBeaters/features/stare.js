// Function to set the player's camera to look at the exact center of target coordinates
export function lookAtCoordinates(targetX, targetY, targetZ) {
    const player = Client.getMinecraft().field_71439_g;
    const playerPos = player.func_174791_d(); // Player's precise position (Vec3d)

    // Adjust target coordinates to the center of the block (0.5 offset)
    const centerX = targetX + 0.5;
    const centerY = targetY + 0.5;
    const centerZ = targetZ + 0.5;

    // Calculate the direction vector from player to the center of the target block
    const dx = centerX - playerPos.field_72450_a;
    const dy = centerY - (playerPos.field_72448_b + player.func_70047_e()); // Adjust for player eye height
    const dz = centerZ - playerPos.field_72449_c;

    // Calculate yaw and pitch to precisely look at the center of the target
    const yaw = Math.atan2(dz, dx) * (180 / Math.PI) - 90;
    const distanceXZ = Math.sqrt(dx * dx + dz * dz);
    const pitch = -Math.atan2(dy, distanceXZ) * (180 / Math.PI);

    // Set the player's yaw and pitch to face the center of the target coordinates
    player.field_70177_z = yaw; // Yaw
    player.field_70125_A = pitch; // Pitch
}

// Register the /rotata command with dynamic coordinates
register("command", (x, y, z) => {
    // Validate and parse input coordinates
    if (isNaN(x) || isNaN(y) || isNaN(z)) {
        ChatLib.chat("&cInvalid coordinates! Usage: /rotata <x> <y> <z>");
        return;
    }

    const targetX = parseFloat(x);
    const targetY = parseFloat(y);
    const targetZ = parseFloat(z);

    // Call function to rotate player towards the exact center of specified coordinates
    lookAtCoordinates(targetX, targetY, targetZ);

    // Notify the player
    ChatLib.chat(`&aRotated to look at the center of coordinates: X=${targetX}, Y=${targetY}, Z=${targetZ}`);
}).setName("rotata");
