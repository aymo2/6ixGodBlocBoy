function getRandomFloat(min, max, decimalPlaces = 2) {
    const randomFloat = Math.random() * (max - min) + min;
    return parseFloat(randomFloat.toFixed(decimalPlaces));
}

register("chat", (message) => {
    let msg = ChatLib.removeFormatting(ChatLib.getChatMessage(message));

    if (msg.includes("Party >")) { 
        // Respond to "!skyllist" command
        if (msg.includes("!skyllist")) {
            ChatLib.command("pc Go, go, go, go Head so good, she a honor roll She'll ride the disemploy like a carnival I done did the impossible Go, go, go, go Head so good, she a honor roll She'll ride the disemploy like a carnival I done did the impossible Ha, ha, ha, schyeah Way too rich to drive a Rove' Made a milli' off the stove");
        }

        // Respond to "!adriancamp" command with random time
        if (msg.includes("!adriancamp")) {
            ChatLib.command("pc Watcher took " + getRandomFloat(57, 93) + " seconds to clear.");
        }

        // Respond to "!lowskill" command
        if (msg.includes("!lowskill")) { 
            ChatLib.command("pc step into the danger zone M7");
        }
        // Respond to "!likewho"
        if (msg.includes("!likewho")) {
            ChatLib.command("pc Watcher took " + getRandomFloat(62, 100) + " seconds to clear.");
        }
        // Respond to "!disemploy" command
        if (msg.includes("!disemploy")) { 
            ChatLib.command("pc man im full legit man watafak stop accusing me of cheter");
        }
        // Respond to "!brainrot" command
        if (msg.includes("!brainrot")) { 
            ChatLib.command("pc omg i love toilets lololololol very cool");
        }
        // Respond to "!brainrot" command
        if (msg.includes("!nick")) { 
            ChatLib.command("pc PLEASE TELL ASA TO UNBAN ME BRO PLEASEEEE");
        }
        // Respond to "!brainrot" command
        if (msg.includes("!skylisti")) { 
            ChatLib.command("pc GIV DOUBLE PLEASE?? BOOM BOOMMMMMMMMMMMMMMMMMMMMMMMMMMM");
        }
    }
});
