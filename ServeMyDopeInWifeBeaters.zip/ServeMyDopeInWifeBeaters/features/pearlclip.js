let distance = 0; // Initialize the distance variable
let message = "&f[&6Mo&f] "; // Define a message prefix
let clipActive = false; // Flag to check if clip is active
let robot; // Declare the Robot variable

// Initialize the Robot instance
try {
    robot = new java.awt.Robot();
} catch (error) {
    ChatLib.chat("&cError creating Robot instance: " + error);
}

// Event listener for packetReceived with proper packet handling
const pearlclip = register("packetReceived", (packet) => {
    if (clipActive && packet instanceof net.minecraft.network.play.server.S08PacketPlayerPosLook) {
        setTimeout(() => {
            Player.getPlayer().func_70107_b(
                Math.floor(Player.getX()) + 0.5,
                Math.floor(Player.getY()) - distance,
                Math.floor(Player.getZ()) + 0.5
            );
        }, 50); // Adjust the delay if necessary
        clipActive = false;
        ChatLib.chat(message + "Teleported down " + distance + " blocks!");
    }
}).unregister();

// Command to activate pearlclip with distance parameter
register("command", (y) => {
    if (isNaN(y)) {
        ChatLib.chat(message + "Please use a number");
        return;
    }
    if (Math.abs(y) < 40.1 && Math.abs(y) > 3) {
        distance = Math.abs(y);
        clipActive = true;
        pearlclip.register();
        ChatLib.chat(message + "PearlClip activated for " + distance + " blocks. Rotating and throwing your pearl now!");

        // Rotate using the /rotate command and then throw the pearl
        rotateAndThrowPearl(0, 90); // Rotate to yaw: 0 and pitch: 90 before throwing
    } else {
        ChatLib.chat(message + "Distance has to be between 40 and 3");
    }
}).setName("pearlclip");

// Function to rotate using /rotate and then throw the Ender Pearl
const rotateAndThrowPearl = (yaw, pitch) => {
    // Run the /rotate command to set the player's orientation
    ChatLib.command(`rotate ${yaw} ${pitch}`, true); // Rotate the player silently (without showing the command in chat)

    // Swap to the Ender Pearl and throw it in the player's current direction
    const pearlSlot = Player.getInventory().getItems().slice(0, 9).findIndex(
        (item) => item && item.getName() && item.getName().toLowerCase().includes("ender pearl")
    );

    if (pearlSlot === -1) {
        ChatLib.chat("&4Ender Pearl not found in hotbar!");
        return;
    }

    const initialIndex = Player.getHeldItemIndex();
    const shouldSwap = initialIndex !== pearlSlot;
    if (shouldSwap) Player.setHeldItemIndex(pearlSlot);

    // Use Robot to right-click (throw the Ender Pearl) with an extended delay
    setTimeout(() => {
        robot.mousePress(java.awt.event.InputEvent.BUTTON3_DOWN_MASK); // Simulate right mouse button press
        robot.mouseRelease(java.awt.event.InputEvent.BUTTON3_DOWN_MASK); // Simulate right mouse button release
        ChatLib.chat(message + `Ender Pearl thrown after rotating to yaw: ${yaw}, pitch: ${pitch}!`);
    }, 150); // Extended delay before throwing the pearl (500 milliseconds)
};

// Command to deactivate pearlclip
register("command", () => {
    pearlclip.unregister();
    clipActive = false;
    ChatLib.chat(message + "PearlClip deactivated!");
}).setName("nopearlclip");

// Register a chat message listener to detect successful pearl throws
register("chat", (event) => {
    const chatMessage = ChatLib.removeFormatting(event.getMessage().getUnformattedText()).toLowerCase(); // Extract message properly
    if (chatMessage.includes("you threw an ender pearl")) {
        ChatLib.chat(message + "Pearl throw detected. Waiting for teleport...");
    }
});
