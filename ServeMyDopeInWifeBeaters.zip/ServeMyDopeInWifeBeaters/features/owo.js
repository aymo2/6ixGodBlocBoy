// Variable to keep track of the functionality state
let isEnabled = true;

// Register a chat trigger
register("chat", (message, event) => {
    if (!isEnabled) return;

    // Check if the message contains "ping" (case-insensitive)
    if (message.toLowerCase().includes("tresspass")) {
        // Send a chat message saying "Pong!"
        ChatLib.say("/pc !start");
    }
}).setChatCriteria("${message}");