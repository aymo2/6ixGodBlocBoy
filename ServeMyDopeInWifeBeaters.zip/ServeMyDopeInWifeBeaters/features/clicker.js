// Constants
const PREFIX = "&f[&cMoClient&f]";

// Function to perform a left click using the Robot class
function leftClick() {
    ChatLib.chat(PREFIX + " &ftrynna click");

    // Execute the click in a new thread to prevent game freezes
    new Thread(() => {
        try {
            const Robot = Java.type("java.awt.Robot");
            const InputEvent = Java.type("java.awt.event.InputEvent");
            const robot = new Robot();

            robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
            robot.delay(5); // Reduced delay to minimize freezing
            robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
            ChatLib.chat(PREFIX + " &fitem pickup");
        } catch (e) {
            ChatLib.chat(PREFIX + " &cError with Robot method: " + e);
        }
    }).start();
}

// Register a sound event for item pickup
register("soundPlay", (position, name, volume, pitch, categoryName, event) => {
    if (name === "random.pop" || name === "item.pickup") {
        ChatLib.chat(PREFIX + " &0clicking!");
        leftClick();
    }
});

// Log when the mod is loaded
ChatLib.chat(PREFIX + " &aMod loaded successfully");

// WorldLoad event to ensure the mod is running
register("worldLoad", () => {
    ChatLib.chat(PREFIX + " &aWorld loaded, mod is active");
});